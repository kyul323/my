// 보은, 옥천, 영동

var polygonPath_East = {
    
}